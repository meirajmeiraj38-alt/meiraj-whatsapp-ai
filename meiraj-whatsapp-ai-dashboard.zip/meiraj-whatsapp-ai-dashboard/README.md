# Meiraj AI WhatsApp Dashboard

This project includes an HTML dashboard and a Node.js backend. HTML alone cannot connect to WhatsApp; the backend communicates with Meta's official WhatsApp Cloud API and OpenAI.

## Run
1. Install Node.js 20+.
2. Copy `.env.example` to `.env` and fill in the credentials.
3. Run `npm install` then `npm start`.
4. Open `http://localhost:3000`.
5. Enter the `DASHBOARD_PASSWORD` you set in `.env`.

## Deploy online
Deploy this as a Node.js web service on Render or another host. Build command: `npm install`; start command: `npm start`. Add all `.env` values in the host's environment-variable settings. Use HTTPS.

## Meta webhook
Set the callback URL to `https://YOUR-DOMAIN/webhook` and the verify token to the exact `WA_VERIFY_TOKEN`. Subscribe to the `messages` webhook field. For production, set `META_APP_SECRET` so webhook signatures are checked.

## Meta credentials
`WA_PHONE_NUMBER_ID` and `WA_ACCESS_TOKEN` are from the WhatsApp Cloud API setup in your Meta app. Use a correctly permissioned long-lived/system-user token for production. Do not publish `.env`, tokens, or passwords.

## Important limitations and policies
- Existing WhatsApp Business app numbers must be onboarded through Meta's supported Coexistence flow if you want to keep using the app and API together. Eligibility and onboarding depend on Meta's current process. Do not delete or migrate the number just to test.
- This sample auto-replies to inbound messages. Business-initiated messages outside the customer-service window generally require approved templates and customer opt-in. Do not send unsolicited bulk messages; respect opt-outs and WhatsApp policies.
- The manual send endpoint is intended for legitimate customer conversations and remains subject to WhatsApp's messaging rules.
- Conversation history and duplicate-message cache are in memory and reset on restart. Use a database/queue and stronger production controls before handling real customer traffic.
- The dashboard password is sent to the backend over HTTP headers. Only use this dashboard over HTTPS in deployment. Add stronger user authentication/rate limiting before production.
- The WhatsApp connection status means credentials are configured; it does not independently verify that Meta has approved or activated the number.
