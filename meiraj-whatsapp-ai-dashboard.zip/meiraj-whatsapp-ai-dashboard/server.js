import "dotenv/config";
import express from "express";
import crypto from "node:crypto";
import OpenAI from "openai";
import path from "node:path";
import { fileURLToPath } from "node:url";

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const app = express();
app.use(express.json({ verify: (req, res, buf) => { req.rawBody = buf; } }));
app.use(express.static(path.join(__dirname, "public")));

const required = ["WA_PHONE_NUMBER_ID", "WA_ACCESS_TOKEN", "WA_VERIFY_TOKEN", "OPENAI_API_KEY", "DASHBOARD_PASSWORD"];
const missing = required.filter(k => !process.env[k]);
if (missing.length) {
  console.error("Missing environment variables:", missing.join(", "));
  process.exit(1);
}

const openai = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });
const GRAPH_VERSION = process.env.GRAPH_API_VERSION || "vXX.X";
const PORT = Number(process.env.PORT || 3000);
let autoReplyEnabled = true;
const conversations = new Map();
const processed = new Set();

const businessName = process.env.BUSINESS_NAME || "Meiraj Digital Skill";
const businessDescription = process.env.BUSINESS_DESCRIPTION ||
  "We teach AI videos, AI marketing, graphic design, coding, website building, and portfolio building.";

function requireDashboard(req, res, next) {
  const supplied = req.get("x-dashboard-password") || "";
  const a = Buffer.from(supplied);
  const b = Buffer.from(process.env.DASHBOARD_PASSWORD || "");
  if (a.length !== b.length || !crypto.timingSafeEqual(a, b)) {
    return res.status(401).json({ error: "Unauthorized. Enter your dashboard password." });
  }
  next();
}

function verifyMetaSignature(req) {
  const secret = process.env.META_APP_SECRET;
  if (!secret) return true; // Configure META_APP_SECRET for production.
  const signature = req.get("x-hub-signature-256") || "";
  const expected = "sha256=" + crypto.createHmac("sha256", secret)
    .update(req.rawBody || Buffer.from("")).digest("hex");
  const a = Buffer.from(signature), b = Buffer.from(expected);
  return a.length === b.length && crypto.timingSafeEqual(a, b);
}

async function sendWhatsAppText(to, body) {
  const url = `https://graph.facebook.com/${GRAPH_VERSION}/${process.env.WA_PHONE_NUMBER_ID}/messages`;
  const response = await fetch(url, {
    method: "POST",
    headers: {
      Authorization: `Bearer ${process.env.WA_ACCESS_TOKEN}`,
      "Content-Type": "application/json"
    },
    body: JSON.stringify({
      messaging_product: "whatsapp",
      recipient_type: "individual",
      to,
      type: "text",
      text: { preview_url: false, body: String(body).slice(0, 4096) }
    })
  });
  const data = await response.json().catch(() => ({}));
  if (!response.ok) {
    console.error("WhatsApp API error:", response.status, data);
    throw new Error(data?.error?.message || `WhatsApp API error ${response.status}`);
  }
  return data;
}

const instructions = `
You are the WhatsApp customer-support assistant for ${businessName}.
Business details: ${businessDescription}
Business hours: ${process.env.BUSINESS_HOURS || "Ask the business owner for current hours."}

Reply briefly and politely, suitable for WhatsApp. Match the customer's language (Urdu, Roman Urdu, or English).
Do not invent prices, schedules, guarantees, contact details, or policies. If you do not know something, say so and offer human assistance.
If asked for a human, say: ${process.env.HUMAN_HANDOFF_MESSAGE || "A team member will contact you soon."}
Do not claim that a booking, payment, or other action has been completed unless confirmed.
`;

async function aiReply(phone, text) {
  const history = conversations.get(phone) || [];
  const result = await openai.responses.create({
    model: process.env.OPENAI_MODEL || "gpt-5.5",
    instructions,
    input: [...history, { role: "user", content: text }]
  });
  const answer = (result.output_text || "").trim() ||
    "Sorry, I couldn't prepare a reply. A team member will help you.";
  conversations.set(phone, [
    ...history,
    { role: "user", content: text },
    { role: "assistant", content: answer }
  ].slice(-12));
  return answer;
}

function getMessageText(message) {
  if (message.type === "text") return message.text?.body?.trim() || "";
  if (message.type === "button") return message.button?.text?.trim() || "";
  if (message.type === "interactive") {
    return message.interactive?.button_reply?.title ||
      message.interactive?.list_reply?.title || "";
  }
  return "";
}

async function handleIncoming(message) {
  if (!message?.id || processed.has(message.id)) return;
  processed.add(message.id);
  if (processed.size > 5000) processed.delete(processed.values().next().value);

  const phone = message.from;
  if (!phone) return;
  const text = getMessageText(message);

  if (!autoReplyEnabled) return; // Messages are received, but AI auto-replies are paused.
  if (!text) {
    await sendWhatsAppText(phone, "Thanks for contacting us. Please send your question as a text message.");
    return;
  }

  try {
    const answer = await aiReply(phone, text);
    await sendWhatsAppText(phone, answer);
  } catch (err) {
    console.error("Auto-reply failed:", err);
    try { await sendWhatsAppText(phone, "Sorry, I'm having a technical issue. Please try again shortly."); }
    catch (sendErr) { console.error("Fallback send failed:", sendErr); }
  }
}

app.get("/api/status", requireDashboard, (req, res) => {
  res.json({
    connected: Boolean(process.env.WA_PHONE_NUMBER_ID && process.env.WA_ACCESS_TOKEN),
    autoReplyEnabled,
    businessName
  });
});

app.post("/api/auto-reply", requireDashboard, (req, res) => {
  if (typeof req.body.enabled !== "boolean") {
    return res.status(400).json({ error: "enabled must be true or false" });
  }
  autoReplyEnabled = req.body.enabled;
  res.json({ autoReplyEnabled });
});

app.post("/api/send", requireDashboard, async (req, res) => {
  const { phone, message } = req.body || {};
  if (!phone || !message || typeof message !== "string") {
    return res.status(400).json({ error: "Enter recipient phone number and message." });
  }
  try {
    const result = await sendWhatsAppText(String(phone).replace(/[^\d]/g, ""), message);
    res.json({ sent: true, result });
  } catch (err) {
    res.status(502).json({ error: err.message });
  }
});

app.get("/webhook", (req, res) => {
  const mode = req.query["hub.mode"];
  const token = req.query["hub.verify_token"];
  const challenge = req.query["hub.challenge"];
  if (mode === "subscribe" && token === process.env.WA_VERIFY_TOKEN) return res.status(200).send(challenge);
  return res.sendStatus(403);
});

app.post("/webhook", (req, res) => {
  if (!verifyMetaSignature(req)) return res.sendStatus(401);
  res.sendStatus(200);
  if (req.body?.object !== "whatsapp_business_account") return;
  for (const entry of req.body.entry || []) {
    for (const change of entry.changes || []) {
      for (const msg of change.value?.messages || []) void handleIncoming(msg);
    }
  }
});

app.listen(PORT, () => console.log(`Dashboard running on port ${PORT}`));
